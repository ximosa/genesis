export default function getCurrentUserData() {
	return atomic_globals.user_data;
}
